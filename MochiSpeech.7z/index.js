const express = require("express");
const https = require("https");
const fs = require("fs");

const app = express();
const port = 3000;

// Rota simples
app.use(express.static(__dirname + "/root"));

// Rota proxy
app.get("/req", async (req, res) => {
  try {
    const { gpio, state } = req.query;
    if (!gpio || !state) {
      return res.status(400).json({ error: "Parâmetros gpio e state são obrigatórios" });
    }

    // Monta a URL de destino
    const target = `http://192.168.4.1/update?gpio=${encodeURIComponent(gpio)}&state=${encodeURIComponent(state)}`;

    console.log(`🔄 Forward para: ${target}`);

    // Faz a requisição para o dispositivo
    const response = await fetch(target);
    const data = await response.text();

    // Repassa a resposta para o cliente
    res.status(response.status);
    res.set("content-type", response.headers.get("content-type") || "text/plain");
    res.send(data);

  } catch (err) {
    console.error("Erro ao forwardar:", err);
    res.status(500).json({ error: "Erro ao se comunicar com 192.168.4.1" });
  }
});


// Ler certificados
const options = {
  key: fs.readFileSync("key.pem"),
  cert: fs.readFileSync("cert.pem"),
};

// Criar servidor HTTPS
https.createServer(options, app).listen(port, () => {
  console.log(`Servidor rodando em https://localhost:${port}`);
});
